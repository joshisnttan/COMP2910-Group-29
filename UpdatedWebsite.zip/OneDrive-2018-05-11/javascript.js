// canvas = document.getElementById('myCanvas');
// //
// // canvas.width = window.innerWidth;
// // canvas.height = window.innerHeight;
// //
// // var canvas;
// // var canvasWidth;
// // var ctx;
// //
// // function init() {
// //     canvas = document.getElementById('canvas');
// //     if (canvas.getContext) {
// //         ctx = canvas.getContext("2d");
// //
// //         window.addEventListener('resize', resizeCanvas, false);
// //         window.addEventListener('orientationchange', resizeCanvas, false);
// //         resizeCanvas();
// //     }
// // }
// //
// // function resizeCanvas() {
// //     canvas.width = window.innerWidth;
// //     canvas.height = window.innerHeight;
// // }
// //
// // var width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
// // var height  = (window.innerHeight > 0) ? window.innerHeight : screen.height;
//
// function resizeCanvas() {
//     canvas = document.getElementById("myCanvas");
//     canvas.width = window.innerWidth;
//     canvas.height = window.innerHeight;
// }