myGame.Preload.prototype = {
  preload: function() {
    // Preload font for the game
    this.load.script('webfont', '//ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js');
    
    //Preload start button
    this.load.spritesheet('startButton', 'assets/ui/button-start.png', 256, 64);
    
    //Dialog background
    this.load.image('dialogWindow', 'assets/ui/dialog.png');
    
    //Sound
    // this.load.audio('button', [ 'assets/audio/button.mp3', 'assets/audio/button.wav' ]);
    // this.load.audio('pen', [ 'assets/audio/pen.mp3', 'assets/audio/pen.wav' ]);
    // this.load.audio('meow', [ 'assets/audio/meow.mp3', 'assets/audio/meow.wav' ]);
    // this.load.audio('dice', [ 'assets/audio/dice.mp3', 'assets/audio/dice.wav' ]);

      this.load.image('background', 'img/bg-floor.png');
      this.load.image('player', 'img/compost.png');
      this.load.image('meat', 'img/meat.png');
      this.load.image('meat-count', 'img/meat-count.png');
      this.load.image('recycle', 'img/recycle.png');
      this.load.image('trash', 'img/trash.png');
      this.load.image('poop', 'img/poop.png');
      this.load.image('tomato', 'img/tomato.png');
      this.load.image('flower', 'img/flower.png');
      this.load.image('gameboy', 'img/gameboy.png');
      this.load.image('laptop', 'img/laptop.png');
      this.load.audio('correct', 'img/correct.mp3');
      this.load.audio('incorrect', 'img/incorrect.mp3');

      this.load.image('menuBG', 'img/Menu.png');
      this.load.image('worldMap', 'img/map.png');
      this.load.image('town', 'img/town.png');
  },

  create: function() {
    this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    this.scale.pageAlignHorizontally = true;
    this.scale.pageAlignVertically = true;
    this.scale.setScreenSize(true);
    this.stage.smoothed = false;
    
    this.state.start('MainMenu');
  },
  update: function() {}
}
