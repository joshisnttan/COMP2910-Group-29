myGame.Map.prototype = {
  preload: function() {
    // Objects have been preloaded at beginning of game in 'Preload' state
  },

  create: function() {
    //this.stage.backgroundColor = '#03826n';
    game.add.image(0,0, 'worldMap');

    myGame.showTitleText(game.world.centerY/2, 'CompostKing');
    
    myGame.chinaButton = this.add.button(this.world.centerX, 400, 'China', this.startGame, this, 1, 0, 2);
    myGame.indiaButton = this.add.button(this.world.centerX, 500, 'India', this.startGame, this, 1, 0, 2);
    myGame.brazilButton = this.add.button(this.world.centerX, 600, 'India', this.startGame, this, 1, 0, 2);

    myGame.startButton.anchor.setTo(0.5);
    
    myGame.showNoteText(250, '*Instructions* \n\n Click and drag the falling items into the correct bin \n');
  },

  update: function() {
    
  },
  startGame: function() {
    this.state.start('GamePlay1');
  }
}

